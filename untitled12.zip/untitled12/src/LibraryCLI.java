import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class LibraryCLI {
    private static LibraryCatalog catalog;
    private static Librarian librarian;
    public static void main(String[] args) {
        catalog = new LibraryCatalog();
        librarian = new Librarian("John Doe");
        Scanner scanner = new Scanner(System.in);
        int choice = -1;
        while (choice != 0) {
            displayMenu();
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    addBook(scanner);
                    break;
                case 2:
                    addMagazine(scanner);
                    break;
                case 3:
                    addCD(scanner);
                    break;
                case 4:
                    removeItem(scanner);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
    private static void displayMenu() {
        System.out.println("Library Catalog System");
        System.out.println("----------------------");
        System.out.println("1. Add Book");
        System.out.println("2. Add Magazine");
        System.out.println("3. Add CD");
        System.out.println("4. Remove Item");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }
    private static void addBook(Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter ISBN: ");
        String isbn = scanner.nextLine();
        Book book = new Book(title, author, isbn);
        librarian.addItem(book);
        catalog.addItem(book);
        System.out.println("Book added successfully.");
    }
    private static void addMagazine(Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter issue number: ");
        int issueNumber = scanner.nextInt();
        scanner.nextLine();
        Magazine magazine = new Magazine(title, author, issueNumber);
        librarian.addItem(magazine);
        catalog.addItem(magazine);
        System.out.println("Magazine added successfully.");
    }
    private static void addCD(Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter duration: ");
        int duration = scanner.nextInt();
        scanner.nextLine();
        CD cd = new CD(title, author, duration);
        librarian.addItem(cd);
        catalog.addItem(cd);
        System.out.println("CD added successfully.");
    }
    private static void removeItem(Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        Item item = catalog.findItemByTitleAndAuthor(title, author);
        if (item != null) {
            librarian.removeItem(item);
            catalog.removeItem(item);
            System.out.println("Item removed successfully.");
        } else {
            System.out.println("Item not found in the catalog.");
        }
    }
}
abstract class Item {
    protected String title;
    protected String author;
    public Item(String title, String author) {
        this.title = title;
        this.author = author;
    }
    public abstract String getType();
}
class LibraryCatalog {
    private List<Item> catalog;
    public LibraryCatalog() {
        catalog = new ArrayList<>();
    }
    public void addItem(Item item) {
        catalog.add(item);
    }
    public void removeItem(Item item) {
        catalog.remove(item);
    }
    public Item findItemByTitleAndAuthor(String title, String author) {
        for (Item item : catalog) {
            if (item.title.equals(title) && item.author.equals(author)) {
                return item;
            }
        }
        return null;
    }
}
abstract class User {
    protected String name;
    public User(String name) {
        this.name = name;
    }
}
class Librarian extends User {
    public Librarian(String name) {
        super(name);
    }
    public void addItem(Item item) {
    }
    public void removeItem(Item item) {
    }
}
class Book extends Item {
    private String isbn;
    public Book(String title, String author, String isbn) {
        super(title, author);
        this.isbn = isbn;
    }
    public String getType() {
        return "Book";
    }
}
class Magazine extends Item {
    private int issueNumber;
    public Magazine(String title, String author, int issueNumber) {
        super(title, author);
        this.issueNumber = issueNumber;
    }
    public String getType() {
        return "Magazine";
    }
}
class CD extends Item {
    private int duration;
    public CD(String title, String author, int duration) {
        super(title, author);
        this.duration = duration;
    }
    public String getType() {
        return "CD";
    }
}